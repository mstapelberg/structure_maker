#!/bin/bash
rm -rf __pycache__
rm -f *.out
rm -f *.rst
rm -f movie.xyz
rm -f amber.out

